<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if (isset($_POST['owner']))
{
if (isset($_POST['password']))
{
       $owner = $_POST['owner'];
    $password = $_POST['password'];
	$hwid = $_POST['hwid'];
    $computer = $_POST['computer'];
    $key = $_POST['key'];
    $role = $_POST['role'];
    $myfile = fopen("./Users/". $owner .  ".txt", "w") or die("Unable to open file!");
    $myfile = fopen("./Users/Details/". $owner .  ".txt", "w") or die("Unable to open file!");
    $myfile = fopen("./Users/News/". $owner .  ".txt", "w") or die("Unable to open file!");
    $myfile = fopen('./Logs/Checker/'. $owner .  '.txt', "w") or die("Unable to open file!");
    $myfile = fopen('./Users/Keys/'. $owner .  '.txt', "w") or die("Unable to open file!");
    $myfile = fopen('./Users/Settings/'. $owner .  '.txt', "w") or die("Unable to open file!");
    $myfile = fopen('./Users/Bildirim/'. $owner .  '.txt', "w") or die("Unable to open file!");
    $txt = $password . ";" . $owner . ";" . $hwid . ";" . $computer. ";" . $license . "+";
    $txt2 = $hwid;
    $myfile2 = fopen("./Users/Hwids/". $owner .  ".txt", "w") or die("Unable to open file!");
    file_put_contents("./Users/Hwids/" . $owner . ".txt", file_get_contents("./Users/Hwids/" . $owner . ".txt") . $txt2);
    file_put_contents("registered.txt", file_get_contents("registered.txt") . $txt);
    file_put_contents('./Users/Keys/'. $owner .  '.txt', file_get_contents('./Users/Keys/'. $owner .  '.txt') . $key);
    $settings = "Hwid;Enabled+Premium;Disabled+AAP;Disabled";
    file_put_contents('./Users/Settings/'. $owner .  '.txt', file_get_contents('./Users/Settings/'. $owner .  '.txt') . $settings);
    $settingsz = "file;none";
    file_put_contents('./Users/Bildirim/'. $owner .  '.txt', file_get_contents('./Users/Bildirim/'. $owner .  '.txt') . $settingsz);
    echo 'Registered';
}
}
?>