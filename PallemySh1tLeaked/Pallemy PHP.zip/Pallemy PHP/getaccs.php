<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if(isset($_POST['key']))
{
if (isset($_POST['username']))
{
if (isset($_POST['password']))
{
  $key = $_POST['key'];
  $abd = fopen('key.txt','r');
$texts1 = "";
while ($line1 = fgets($abd)) {
  $texts1 .= $line1;
}
  if (strpos($texts1, $key) !== false) 
{
$username = htmlspecialchars($_POST['username']);
$password = $_POST['password'];
$text = $password . ";" . $username;
$fh = fopen('registered.txt','r');
$fh1 = fopen("./Users/News/". $username .  ".txt", "r");
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
$news = "";
while ($line1 = fgets($fh1)) {
  $news .= $line1;
}
if (strpos($texts, $text) !== false) 
{
if (strpos($news, "news") !== false) 
{

  $text = $password . ";" . $username;
  $fh = fopen("./Users/".$username . ".txt",'r');
  $texts = "";
  while ($line = fgets($fh)) {
    $texts .= $line;
  }
  echo $texts;
  $fh = fopen("./Users/News/". $username .  ".txt", "w");
  file_put_contents("./Users/News/" . $username . ".txt", file_get_contents("./Users/News/" . $username . ".txt") . "nothingzz");

  }
  else
  {
    echo "nothing";
    if (strpos($texts, $text) !== false) 
    {
    $text = $password . ";" . $username;
    $fh = fopen("./Users/".$username . ".txt",'r');
    $texts = "";
    while ($line = fgets($fh)) {
      $texts .= $line;
    }
    echo $texts;
    $fh = fopen("./Users/News/". $username .  ".txt", "w");
    file_put_contents("./Users/News/" . $username . ".txt", file_get_contents("./Users/News/" . $username . ".txt") . "nothing");
  }
  fclose($fh);
}
}

}
else
{
  echo "You dont have permissions.";
}
}

}
}
?>