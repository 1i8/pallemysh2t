<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if (isset($_POST['check']))
{
    $check = $_POST['check'];
      $ownerhwid = $_POST['ownerhwid'];
      $fh = fopen('blacklistedpublic.txt','r');
    $texts = "";
    while ($hwid = fgets($fh)) {
      $texts .= $hwid;
    }

    $myfile = fopen("./Users/Hwids/". $ownerhwid .  ".txt", "r") or die("Unable to open file!");
    $texts = "";
    while ($line = fgets($myfile)) {
        $texts .= $line;
      }

    $txt = $texts . ";";

      if (strpos($hwid, $texts) !== false) 
    {
echo "false";
    fclose($fh);
}
else{
  echo "true";
}
}
if (isset($_POST['hwidban']))
{
    $hwidban = $_POST['hwidban'];
    $ownerzz = $_POST['ownerzz'];
    $myfile = fopen("./Users/Hwids/". $ownerzz .  ".txt", "r") or die("Unable to open file!");
    $texts = "";
    while ($line = fgets($myfile)) {
        $texts .= $line;
      }

    $txt = $texts . ";";
    file_put_contents("blacklistedpublic.txt", file_get_contents("blacklistedpublic.txt") . $txt);
    echo 'Banned Hwid';
}
if (isset($_POST['remove']))
{
    $username = $_POST['username'];
    $remove = $_POST['remove'];
    $text = $username . ";";
    $contents = file_get_contents("blacklisted.txt",'r');
    $contents = str_replace($text, "", $contents);
    file_put_contents("blacklisted.txt", $contents);
    echo 'Deleted';
}
if (isset($_POST['owner']))
{
    $owner = $_POST['owner'];
    $txt = $owner . ";";
    file_put_contents("blacklisted.txt", file_get_contents("blacklisted.txt") . $txt);
    echo 'Blacklisted';
}

?>