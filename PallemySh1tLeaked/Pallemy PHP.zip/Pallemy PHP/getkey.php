<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if (isset($_POST['hwid']))
{
  $hwid = $_POST['hwid'];
  $fh = fopen('adminhwids.txt','r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
  if (strpos($texts, $hwid) !== false) 
{
$fh = fopen("key.txt",'r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
echo $texts;
}
else
{
 echo "You dont have permissions."; 
}
fclose($fh);
}
?>