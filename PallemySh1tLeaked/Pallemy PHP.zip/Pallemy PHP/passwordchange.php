<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
    }
    if (isset($_POST['owner']))
    {
$owner = $_POST['owner'];
$oldpw = $_POST['oldpw'];
$newpw = $_POST['newpw'];
$changetext = $oldpw . ";" . $owner;
$fh = fopen('registered.txt','r');
$texts = "";
while ($line = fgets($fh)) 
{
    $texts .= $line;
}

if (strpos($texts, $changetext) !== false) {
    $changetext2 = $newpw . ";" . $owner;
    $str = implode("\n", file('registered.txt'));
    $fp = fopen('registered.txt', 'w');
    $str = str_replace($changetext, $changetext2, $str);
    fwrite($fp, $str, strlen($str));
    fclose($fp);
    echo "changed";
}
else{
    echo "wrong";
}

    }

?>