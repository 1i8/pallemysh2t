<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
$username = htmlspecialchars($_POST['username']);
$fh = fopen('registered.txt','r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
if (strpos($texts, $username) !== false) 
{
echo "true";
}
else
{
 echo "false"; 
}
fclose($fh);
?>