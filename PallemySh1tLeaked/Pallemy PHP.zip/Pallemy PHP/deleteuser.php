<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
$password = $_POST['password'];
$username = $_POST['username'];
$hwid = $_POST['hwid'];
$computer = $_POST['computer'];

$text = $password . ";" . $username . ";" . $hwid . ";" . $computer . "+";
$contents = file_get_contents("registered.txt",'r');
$contents = str_replace($text, "", $contents);
file_put_contents("registered.txt", $contents);
echo "Deleted User";
?>