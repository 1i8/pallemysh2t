<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
$username = $_POST['username'];
$hwid = htmlspecialchars($_POST['hwid']);
$txta = "Hwid;Disabled";
$fha = fopen("./Users/Settings/". $username .  ".txt",'r');
$aa = "";
while ($lin1e = fgets($fha)) {
  $aa .= $line1;
}
if (strpos($aa, $txta) !== false) 
{
echo "disabled";
}
else
{

$fh = fopen("./Users/Hwids/". $username .  ".txt",'r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
if (strpos($texts, $hwid) !== false) 
{
echo "true";
}
else
{
 echo "false"; 
}
fclose($fh);
}
?>