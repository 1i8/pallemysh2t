<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
if (isset($_POST['key']))
{
  $key = $_POST['key'];
  $fh = fopen('key.txt','r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
  if (strpos($texts, $key) !== false) 
{
$fh = fopen("registered.txt",'r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
echo $texts;
}
else
{
 echo "false"; 
}
fclose($fh);
}
?>