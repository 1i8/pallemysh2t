<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
    }
    if (isset($_POST['bildirim']))
    {
        if (isset($_POST['file']))
        {
            $link = $_POST['link'];
            $str = implode("\n", file('./Users/Bildirim/'. $owner .  '.txt'));
            $fp = fopen('./Users/Settings/'. $owner .  '.txt', 'w');
            $settings = "file;" . $link;
            $str = str_replace("file;none", $settings, $str);
            fwrite($fp, $str, strlen($str));
            fclose($fp);
        }
    }
    if (isset($_POST['checkb']))
    {
            $yuzr = $_POST['yuzr'];
            $str = implode("\n", file('./Users/Bildirim/'. $yuzr .  '.txt'));
            $fp = fopen('./Users/Settings/'. $yuzr .  '.txt', 'w');      
            $setting = "file;none";
$aa = "";
            while ($qwe = fgets($fp)) {
                $aa .= $aa;
              }
              if (strpos($aa, $setting) !== false) 
              {
              echo "none";
              }
              else{
                  echo $str;
              }
    }
    if (isset($_POST['owner']))
    {
$owner = $_POST['owner'];
$str = implode("\n", file('./Users/Settings/'. $owner .  '.txt'));
$fp = fopen('./Users/Settings/'. $owner .  '.txt', 'w');
$str = str_replace("Hwid;Enabled", "Hwid;Disabled", $str);
fwrite($fp, $str, strlen($str));
fclose($fp);
    }
    else if(isset($_POST['username']))
    {
        $owner = $_POST['owner'];
        $str = implode("\n", file('./Users/Settings/'. $owner .  '.txt'));
        $fp = fopen('./Users/Settings/'. $owner .  '.txt', 'w');
        $str = str_replace("Hwid;Disabled", "Hwid;Enabled", $str);
        fwrite($fp, $str, strlen($str));
        fclose($fp);
    }

?>