<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}
$username = htmlspecialchars($_POST['username']);
$fh = fopen('blacklisted.txt','r');
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
if (strpos($texts, $username) !== false) 
{
echo "Blacklisted";
}
else
{
	
}
fclose($fh);
    $username = $_POST['username'];
    $password = $_POST['password'];
    $text = $password . ";" . $username;
    $fh = fopen('registered.txt','r');
    $texts = "";
    while ($line = fgets($fh)) 
    {
        $texts .= $line;
    }

    if (strpos($texts, $text) !== false) {
        echo 'true';
    }
    else
    {
        echo "false";
    }
    fclose($fh);
?>